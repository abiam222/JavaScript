/* global cs */
(function () {
	'use strict';

	// some UI constants
	cs.ns('app.ui').constants = {
		// DOM event key code
		KEY_ENTER: 13,
		KEY_ESCAPE: 27
	};
}());
