# Mithril TodoMVC Example

> [Mithril](http://lhorie.github.io/mithril/) is a client-side MVC framework - a tool to organize code in a way that is easy to think about and to maintain.

> _[Mithril - lhorie.github.io/mithril/](http://lhorie.github.io/mithril/)_

## Learning Mithril

The [Mithril website](http://lhorie.github.io/mithril/getting-started.html) is a great resource for getting started.

Here are some links you may find helpful:

* [Official Documentation](http://lhorie.github.io/mithril/mithril.html)

_If you have other helpful links to share, or find any of the links above no longer work, please [let us know](https://github.com/tastejs/todomvc/issues)._

## Credit
This TodoMVC application was created by [taylorhakes](https://github.com/taylorhakes).